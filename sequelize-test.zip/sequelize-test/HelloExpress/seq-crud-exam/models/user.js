"use strict";

module.exports = (sequelize, DataTypes) => {
  var user = sequelize.define("user", {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isEmail: true, // foo@example.com 이 맞는지 확인
      },
      primaryKey: true, // 고유키로 지정
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    salt: {
      type: DataTypes.STRING,
    },
  });
  return user;
};
